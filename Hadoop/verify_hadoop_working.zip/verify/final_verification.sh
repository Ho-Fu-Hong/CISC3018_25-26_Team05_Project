#!/bin/bash
echo "FINAL HADOOP HDFS VERIFICATION"
echo "==============================="

PASS_COUNT=0
TOTAL_TESTS=6

echo ""
echo "1. Checking Hadoop Services..."
if jps | grep -q "NameNode" && jps | grep -q "DataNode"; then
    echo "   ✅ PASS: Hadoop services running"
    ((PASS_COUNT++))
else
    echo "   ❌ FAIL: Hadoop not running"
    echo "   Run: start-dfs.sh"
fi

echo ""
echo "2. Checking HDFS Access..."
if hdfs dfs -ls / > /dev/null 2>&1; then
    echo "   ✅ PASS: HDFS root accessible"
    ((PASS_COUNT++))
else
    echo "   ❌ FAIL: HDFS not accessible"
fi

echo ""
echo "3. Checking Project Data in HDFS..."
if hdfs dfs -test -e /project/agriculture/raw/yield_df.csv 2>/dev/null; then
    echo "   ✅ PASS: Project data exists"
    ((PASS_COUNT++))
    
    # Show data info
    echo "   Data files found:"
    hdfs dfs -ls /project/agriculture/raw/*.csv 2>/dev/null | awk '{print "     • "$NF}'
    
    # Count lines in main file
    LINE_COUNT=$(hdfs dfs -cat /project/agriculture/raw/yield_df.csv 2>/dev/null | wc -l)
    echo "   yield_df.csv lines: $LINE_COUNT"
    
    # Show columns
    echo "   First line (column headers):"
    hdfs dfs -cat /project/agriculture/raw/yield_df.csv 2>/dev/null | head -1
else
    echo "   ❌ FAIL: No project data in HDFS"
fi

echo ""
echo "4. Testing HDFS Write Permission..."
# Create test file
TEST_CONTENT="Hadoop HDFS Integration Test - Success!\nDate: $(date)\nProject: Agricultural Yield Forecasting"
echo -e "$TEST_CONTENT" > /tmp/hdfs_write_test.txt

# Try to write to HDFS
hdfs dfs -mkdir -p /test_write 2>/dev/null
hdfs dfs -put /tmp/hdfs_write_test.txt /test_write/ 2>/dev/null

if hdfs dfs -test -e /test_write/hdfs_write_test.txt 2>/dev/null; then
    echo "   ✅ PASS: Can write to HDFS"
    ((PASS_COUNT++))
    
    # Verify content
    HDFS_CONTENT=$(hdfs dfs -cat /test_write/hdfs_write_test.txt 2>/dev/null)
    if [[ "$HDFS_CONTENT" == *"Success"* ]]; then
        echo "   ✅ PASS: Content verified"
    fi
    
    # Clean up
    hdfs dfs -rm -r /test_write 2>/dev/null
else
    echo "   ❌ FAIL: Cannot write to HDFS"
    echo "   Fix with: hdfs dfs -chmod -R 777 /project/"
fi

rm /tmp/hdfs_write_test.txt

echo ""
echo "5. Checking Web Interface..."
if curl -s http://localhost:9870 > /dev/null 2>&1; then
    echo "   ✅ PASS: Web UI accessible at http://localhost:9870"
    ((PASS_COUNT++))
else
    echo "   ⚠ WARN: Web UI not accessible"
    echo "   Check if port 9870 is open: sudo ufw allow 9870"
fi

echo ""
echo "6. Saving Integration Report to HDFS..."
# Create report
REPORT_FILE="/tmp/hadoop_integration_final_report.txt"
cat > $REPORT_FILE << REPORT
HADOOP HDFS INTEGRATION - FINAL VERIFICATION REPORT
==================================================
Date: $(date)
Project: Agricultural Yield Forecasting
Team Member: Kelvin (Hadoop Administrator)

TEST RESULTS:
------------
1. Hadoop Services: $(if jps | grep -q "NameNode"; then echo "PASS ✓"; else echo "FAIL ✗"; fi)
2. HDFS Access: $(if hdfs dfs -ls / > /dev/null 2>&1; then echo "PASS ✓"; else echo "FAIL ✗"; fi)
3. Project Data: $(if hdfs dfs -test -e /project/agriculture/raw/yield_df.csv 2>/dev/null; then echo "PASS ✓"; else echo "FAIL ✗"; fi)
4. HDFS Write: $(if [ -f "/tmp/hdfs_write_test.txt" ]; then echo "PASS ✓"; else echo "TEST SKIPPED"; fi)
5. Web UI: $(if curl -s http://localhost:9870 > /dev/null 2>&1; then echo "ACCESSIBLE ✓"; else echo "NOT ACCESSIBLE ✗"; fi)

HDFS STORAGE STATUS:
-------------------
$(hdfs dfs -df -h 2>/dev/null)

PROJECT DATA IN HDFS:
--------------------
$(hdfs dfs -ls -R /project/agriculture/ 2>/dev/null | head -20)

INTEGRATION DETAILS:
-------------------
- HDFS URI: hdfs://localhost:9000
- Project Path: /project/agriculture/
- Main Data File: /project/agriculture/raw/yield_df.csv
- Web Interface: http://localhost:9870
- Hadoop Version: $(hadoop version 2>/dev/null | head -1)

TEAM ACCESS INSTRUCTIONS:
------------------------
1. Download data: hdfs dfs -get /project/agriculture/raw/yield_df.csv
2. Spark access: Use hdfs://localhost:9000/project/agriculture/raw/
3. Web monitoring: http://localhost:9870
4. Check status: jps (should show NameNode, DataNode)

CONCLUSION:
-----------
Hadoop HDFS integration is $(if [ $PASS_COUNT -ge 4 ]; then echo "✅ COMPLETE AND WORKING"; else echo "⚠ PARTIALLY WORKING"; fi)

Total Tests Passed: $PASS_COUNT/$TOTAL_TESTS
REPORT

# Ensure directories exist
hdfs dfs -mkdir -p /project/agriculture/results/ 2>/dev/null

# Fix permissions
hdfs dfs -chmod -R 777 /project/agriculture/ 2>/dev/null

# Upload report
hdfs dfs -put -f $REPORT_FILE /project/agriculture/results/final_integration_report.txt 2>/dev/null

if hdfs dfs -test -e /project/agriculture/results/final_integration_report.txt 2>/dev/null; then
    echo "   ✅ PASS: Report saved to HDFS"
    ((PASS_COUNT++))
    echo "   Location: /project/agriculture/results/final_integration_report.txt"
else
    echo "   ❌ FAIL: Could not save report to HDFS"
    echo "   Manual fix: hdfs dfs -chmod -R 777 /project/"
    echo "   Then: hdfs dfs -put $REPORT_FILE /project/agriculture/results/"
fi

rm $REPORT_FILE

echo ""
echo "==============================="
echo "VERIFICATION COMPLETE"
echo "==============================="
echo ""
echo "TESTS PASSED: $PASS_COUNT/$TOTAL_TESTS"

if [ $PASS_COUNT -eq $TOTAL_TESTS ]; then
    echo ""
    echo "🎉 🎉 🎉 ALL TESTS PASSED! 🎉 🎉 🎉"
    echo ""
    echo "✅ HADOOP HDFS INTEGRATION IS 100% WORKING!"
elif [ $PASS_COUNT -ge 4 ]; then
    echo ""
    echo "✅ HADOOP HDFS INTEGRATION IS WORKING!"
    echo "   (Minor issues that don't affect functionality)"
else
    echo ""
    echo "⚠ HADOOP HDFS INTEGRATION HAS ISSUES"
    echo "   Check the failed tests above"
fi

echo ""
echo "==============================="
echo "FOR DEMONSTRATION:"
echo "==============================="
echo "1. Show Hadoop running:"
echo "   jps"
echo ""
echo "2. Show data in HDFS:"
echo "   hdfs dfs -ls /project/agriculture/"
echo ""
echo "3. Show web interface:"
echo "   echo 'Open: http://localhost:9870'"
echo ""
echo "4. Show verification report:"
echo "   hdfs dfs -cat /project/agriculture/results/final_integration_report.txt"
echo ""
echo "5. Test data access:"
echo "   hdfs dfs -cat /project/agriculture/raw/yield_df.csv | head -3"
echo ""
echo "==============================="
