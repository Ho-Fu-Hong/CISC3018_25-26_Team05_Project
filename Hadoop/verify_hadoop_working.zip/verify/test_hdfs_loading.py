#!/usr/bin/env python3
print("Testing HDFS Data Loading...")
print("=" * 50)

try:
    from pyspark.sql import SparkSession
    
    # Create Spark session with HDFS
    spark = SparkSession.builder \
        .appName("HDFSLoadTest") \
        .config("spark.hadoop.fs.defaultFS", "hdfs://localhost:9000") \
        .getOrCreate()
    
    print("✅ Spark session created")
    print(f"Spark version: {spark.version}")
    
    # Test loading yield_df.csv
    print("\nLoading yield_df.csv from HDFS...")
    df_yield = spark.read \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .csv("hdfs://localhost:9000/project/agriculture/raw/yield_df.csv")
    
    print(f"✅ Successfully loaded yield_df.csv")
    print(f"   Records: {df_yield.count():,}")
    print(f"   Columns: {len(df_yield.columns)}")
    
    # Show schema
    print("\nSchema:")
    df_yield.printSchema()
    
    # Show sample data
    print("\nSample data (first 3 rows):")
    df_yield.show(3, truncate=False)
    
    # Test loading another file
    print("\nLoading temperature data...")
    try:
        df_temp = spark.read \
            .option("header", "true") \
            .option("inferSchema", "true") \
            .csv("hdfs://localhost:9000/project/agriculture/raw/temp.csv")
        print(f"✅ Loaded temp.csv: {df_temp.count()} records")
    except:
        print("⚠ Could not load temp.csv (might not exist)")
    
    spark.stop()
    print("\n" + "=" * 50)
    print("✅ HDFS DATA LOADING TEST PASSED!")
    
except Exception as e:
    print(f"❌ Test failed: {e}")
    import traceback
    traceback.print_exc()
