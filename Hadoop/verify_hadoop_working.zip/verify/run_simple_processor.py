#!/usr/bin/env python3
"""
Simple HDFS processor - run directly without virtual environment issues
"""

import os
import sys
import subprocess

print("=" * 70)
print("SIMPLE HDFS DATA PROCESSOR (Direct Version)")
print("=" * 70)

def check_hadoop():
    """Check if Hadoop is running"""
    print("\n1. Checking Hadoop status...")
    result = subprocess.run(['jps'], capture_output=True, text=True)
    
    if 'NameNode' in result.stdout and 'DataNode' in result.stdout:
        print("   ✅ Hadoop is running")
        return True
    else:
        print("   ❌ Hadoop not running properly")
        print("   Current jps output:")
        print(result.stdout)
        return False

def check_hdfs_data():
    """Check data in HDFS"""
    print("\n2. Checking HDFS data...")
    
    # List files
    result = subprocess.run(['hdfs', 'dfs', '-ls', '/project/agriculture/raw/'],
                          capture_output=True, text=True)
    
    if result.returncode == 0:
        print("   ✅ HDFS accessible")
        lines = result.stdout.strip().split('\n')
        csv_files = [line for line in lines if '.csv' in line]
        print(f"   Found {len(csv_files)} CSV files")
        
        for line in csv_files:
            parts = line.split()
            if len(parts) >= 8:
                print(f"     • {parts[-1]} ({parts[4]} bytes)")
    else:
        print("   ❌ Cannot access HDFS")
        return False
    
    # Check yield_df.csv specifically
    print("\n3. Checking yield_df.csv...")
    result = subprocess.run(['hdfs', 'dfs', '-test', '-e', 
                           '/project/agriculture/raw/yield_df.csv'],
                          capture_output=True)
    
    if result.returncode == 0:
        print("   ✅ yield_df.csv exists in HDFS")
        
        # Get first few lines
        result = subprocess.run(['hdfs', 'dfs', '-cat',
                               '/project/agriculture/raw/yield_df.csv'],
                              capture_output=True, text=True)
        
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            print(f"   Total lines: {len(lines)}")
            
            if len(lines) > 0:
                print(f"   Header (first line):")
                print(f"     {lines[0]}")
                
                # Count columns
                columns = lines[0].split(',')
                print(f"   Columns found: {len(columns)}")
                
                print(f"\n   First few columns:")
                for i, col in enumerate(columns[:10]):
                    print(f"     {i+1}. {col}")
                if len(columns) > 10:
                    print(f"     ... and {len(columns)-10} more")
                
                if len(lines) > 1:
                    print(f"\n   Sample data (first data row):")
                    print(f"     {lines[1]}")
            else:
                print("   ❌ File is empty")
        else:
            print("   ❌ Cannot read file")
    else:
        print("   ❌ yield_df.csv not found")
        return False
    
    return True

def process_and_save():
    """Process and save data"""
    print("\n4. Processing and saving data...")
    
    # Create processed directory
    result = subprocess.run(['hdfs', 'dfs', '-mkdir', '-p',
                           '/project/agriculture/processed/'],
                          capture_output=True)
    
    if result.returncode == 0:
        print("   ✅ Created processed directory")
    else:
        print("   ⚠ Could not create directory (may already exist)")
    
    # Create results directory
    subprocess.run(['hdfs', 'dfs', '-mkdir', '-p',
                   '/project/agriculture/results/'],
                  capture_output=True)
    
    # Copy the CSV file to processed directory (simple copy)
    print("\n5. Copying data to processed directory...")
    result = subprocess.run(['hdfs', 'dfs', '-cp',
                           '/project/agriculture/raw/yield_df.csv',
                           '/project/agriculture/processed/'],
                          capture_output=True)
    
    if result.returncode == 0:
        print("   ✅ Data copied to processed directory")
    else:
        print("   ❌ Could not copy data")
    
    # Create a simple data report
    print("\n6. Creating data report...")
    
    # Get file info
    result = subprocess.run(['hdfs', 'dfs', '-du', '-h',
                           '/project/agriculture/raw/yield_df.csv'],
                          capture_output=True, text=True)
    
    file_size = "Unknown"
    if result.returncode == 0 and result.stdout:
        parts = result.stdout.split()
        if len(parts) >= 2:
            file_size = parts[0]
    
    # Get line count
    result = subprocess.run(['hdfs', 'dfs', '-cat',
                           '/project/agriculture/raw/yield_df.csv',
                           '|', 'wc', '-l'],
                          shell=True, capture_output=True, text=True)
    
    line_count = "Unknown"
    if result.returncode == 0 and result.stdout.strip().isdigit():
        line_count = int(result.stdout.strip())
    
    # Create report
    report = f"""HDFS DATA REPORT
================
Date: $(date)
File: yield_df.csv
Location: /project/agriculture/raw/yield_df.csv
Size: {file_size}
Lines: {line_count}

DATA ACCESS INFORMATION:
- HDFS URI: hdfs://localhost:9000
- Web UI: http://localhost:9870
- Raw data: /project/agriculture/raw/
- Processed data: /project/agriculture/processed/
- Results: /project/agriculture/results/

FOR TEAMMATES:
1. To download: hdfs dfs -get /project/agriculture/raw/yield_df.csv
2. To view: hdfs dfs -cat /project/agriculture/raw/yield_df.csv | head -20
3. Web interface: http://localhost:9870
"""
    
    # Save report locally
    report_file = "/tmp/hdfs_data_report.txt"
    with open(report_file, 'w') as f:
        f.write(report)
    
    # Upload to HDFS
    result = subprocess.run(['hdfs', 'dfs', '-put', report_file,
                           '/project/agriculture/results/'],
                          capture_output=True)
    
    if result.returncode == 0:
        print("   ✅ Report saved to HDFS: /project/agriculture/results/hdfs_data_report.txt")
    else:
        print("   ❌ Could not save report to HDFS")
    
    # Clean up
    os.remove(report_file)
    
    return True

def main():
    """Main function"""
    
    # Check Hadoop
    if not check_hadoop():
        return
    
    # Check HDFS data
    if not check_hdfs_data():
        return
    
    # Process and save
    process_and_save()
    
    print("\n" + "=" * 70)
    print("✅ PROCESSING COMPLETE!")
    print("=" * 70)
    print("\nSummary:")
    print("• Hadoop HDFS is running")
    print("• Data is available in HDFS")
    print("• Data copied to processed directory")
    print("• Report generated")
    
    print("\nHDFS Contents:")
    subprocess.run(['hdfs', 'dfs', '-ls', '-R', '/project/agriculture/'])
    
    print("\n" + "=" * 70)
    print("HADOOP HDFS INTEGRATION VERIFIED AND WORKING")
    print("=" * 70)

if __name__ == "__main__":
    main()
